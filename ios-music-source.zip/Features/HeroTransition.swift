import SwiftUI
import UIKit

/// Global anchors reported by the real pages. The transition never applies
/// matchedGeometryEffect to those pages; it reads their frames and moves one
/// independent hero layer instead.
enum HeroAnchor: Hashable {
    case miniCapsule
    case miniCover
    case miniTitle
    case miniArtist
    case playerCapsule
    case playerCover
    case playerTitle
    case playerArtist
    case lyricsCover
    case lyricsTitle
    case lyricsArtist
}

struct HeroAnchorPreferenceKey: PreferenceKey {
    static var defaultValue: [HeroAnchor: CGRect] = [:]

    static func reduce(value: inout [HeroAnchor: CGRect], nextValue: () -> [HeroAnchor: CGRect]) {
        value.merge(nextValue(), uniquingKeysWith: { _, new in new })
    }
}

extension View {
    func heroAnchor(_ anchor: HeroAnchor) -> some View {
        background(
            GeometryReader { proxy in
                Color.clear.preference(
                    key: HeroAnchorPreferenceKey.self,
                    value: [anchor: proxy.frame(in: .global)]
                )
            }
        )
    }
}

/// Coordinates the compact -> player -> lyrics transition.
///
/// The transition is deliberately two-phase:
/// 1. the destination page is inserted but invisible, so its real anchors can
///    be measured;
/// 2. the single hero layer animates to those measured frames, then the real
///    page fades in.
///
/// This avoids duplicate matched-geometry sources and guessed destination
/// coordinates, which caused the earlier jumping/fading transition.
@MainActor
final class HeroTransitionCoordinator: ObservableObject {
    enum Pending: Equatable {
        case openPlayer
        case closePlayer
        case openLyrics
        case closeLyrics
    }

    @Published private(set) var playerPresented = false
    @Published private(set) var lyricsPresented = false
    @Published private(set) var hideMiniContent = false
    @Published private(set) var hidePlayerContent = false
    @Published private(set) var hidePlayerHero = false
    @Published private(set) var lyricsPageOpacity = 0.0

    @Published private(set) var heroVisible = false
    @Published private(set) var heroTrack: MusicInfo?
    @Published private(set) var coverFrame: CGRect = .zero
    @Published private(set) var titleFrame: CGRect = .zero
    @Published private(set) var artistFrame: CGRect = .zero
    @Published private(set) var coverCornerRadius: CGFloat = 10
    @Published private(set) var titleFontSize: CGFloat = 15
    @Published private(set) var artistFontSize: CGFloat = 11
    @Published private(set) var titleColor: Color = .white
    @Published private(set) var artistColor: Color = .white.opacity(0.62)
    @Published private(set) var shadowOpacity: Double = 0.3
    @Published private(set) var shadowRadius: CGFloat = 8
    @Published private(set) var shadowY: CGFloat = 4

    @Published private(set) var backdropVisible = false
    @Published private(set) var backdropFrame: CGRect = .zero
    @Published private(set) var backdropCornerRadius: CGFloat = 24
    @Published private(set) var backdropOpacity = 1.0

    private var anchors: [HeroAnchor: CGRect] = [:]
    private var pending: Pending?
    @Published private(set) var isAnimating = false
    private var fallbackWorkItem: DispatchWorkItem?

    private var screenBounds: CGRect { UIScreen.main.bounds }

    // MARK: - Anchor updates

    func updateAnchors(_ values: [HeroAnchor: CGRect]) {
        anchors.merge(values, uniquingKeysWith: { _, new in new })

        if pending == .openPlayer, let target = anchors[.playerCover], target.width > 1 {
            DispatchQueue.main.async { [weak self] in self?.finishOpenPlayer() }
        } else if pending == .openLyrics, let target = anchors[.lyricsCover], target.width > 1 {
            DispatchQueue.main.async { [weak self] in self?.finishOpenLyrics() }
        }
    }

    // MARK: - Player

    func openPlayer(track: MusicInfo?) {
        guard !playerPresented, !isAnimating else { return }
        isAnimating = true
        pending = .openPlayer
        heroTrack = track
        anchors.removeValue(forKey: .playerCover)
        anchors.removeValue(forKey: .playerTitle)
        anchors.removeValue(forKey: .playerArtist)
        anchors.removeValue(forKey: .playerCapsule)
        playerPresented = true
        lyricsPresented = false
        lyricsPageOpacity = 0
        hidePlayerContent = true
        hideMiniContent = true
        heroVisible = true

        applyMiniFrames()
        backdropVisible = true
        backdropOpacity = 1
        backdropCornerRadius = 24
        backdropFrame = frame(.miniCapsule, fallback: fallbackMiniCapsule)

        scheduleFallback(after: 0.35) { [weak self] in self?.finishOpenPlayer() }
    }

    func closePlayer() {
        guard playerPresented, !isAnimating else { return }
        isAnimating = true
        pending = .closePlayer
        hidePlayerContent = true
        hideMiniContent = true
        heroVisible = true
        applyPlayerFrames()
        backdropVisible = true
        backdropOpacity = 1
        backdropCornerRadius = 0
        backdropFrame = frame(.playerCapsule, fallback: screenBounds)

        let targetCover = frame(.miniCover, fallback: fallbackMiniCover)
        let targetTitle = frame(.miniTitle, fallback: fallbackMiniTitle)
        let targetArtist = frame(.miniArtist, fallback: fallbackMiniArtist)
        let targetCapsule = frame(.miniCapsule, fallback: fallbackMiniCapsule)

        withAnimation(.spring(response: 0.56, dampingFraction: 0.88)) {
            coverFrame = targetCover
            titleFrame = targetTitle
            artistFrame = targetArtist
            coverCornerRadius = 10
            titleFontSize = 15
            artistFontSize = 11
            titleColor = AppTheme.primaryText
            artistColor = AppTheme.secondaryText
            shadowOpacity = 0.3
            shadowRadius = 8
            shadowY = 4
            backdropFrame = targetCapsule
            backdropCornerRadius = 24
        }

        DispatchQueue.main.asyncAfter(deadline: .now() + 0.58) { [weak self] in
            guard let self else { return }
            self.playerPresented = false
            self.hideMiniContent = false
            self.hidePlayerContent = false
            self.heroVisible = false
            self.backdropVisible = false
            self.isAnimating = false
            self.pending = nil
        }
    }

    private func finishOpenPlayer() {
        guard pending == .openPlayer else { return }
        pending = nil
        fallbackWorkItem?.cancel()

        let targetCover = frame(.playerCover, fallback: fallbackPlayerCover)
        let targetTitle = frame(.playerTitle, fallback: fallbackPlayerTitle)
        let targetArtist = frame(.playerArtist, fallback: fallbackPlayerArtist)
        let targetCapsule = frame(.playerCapsule, fallback: screenBounds)

        withAnimation(.spring(response: 0.62, dampingFraction: 0.86)) {
            coverFrame = targetCover
            titleFrame = targetTitle
            artistFrame = targetArtist
            coverCornerRadius = 14
            titleFontSize = 20
            artistFontSize = 20
            titleColor = .white
            artistColor = .white.opacity(0.62)
            shadowOpacity = 0.55
            shadowRadius = 34
            shadowY = 22
            backdropFrame = targetCapsule
            backdropCornerRadius = 0
        }

        DispatchQueue.main.asyncAfter(deadline: .now() + 0.64) { [weak self] in
            guard let self else { return }
            withAnimation(.easeOut(duration: 0.18)) {
                self.hidePlayerContent = false
                self.heroVisible = false
                self.backdropOpacity = 0
            }
            self.hideMiniContent = false
            self.backdropVisible = false
            self.isAnimating = false
        }
    }

    // MARK: - Lyrics

    func openLyrics() {
        guard playerPresented, !lyricsPresented, !isAnimating else { return }
        isAnimating = true
        pending = .openLyrics
        anchors.removeValue(forKey: .lyricsCover)
        anchors.removeValue(forKey: .lyricsTitle)
        anchors.removeValue(forKey: .lyricsArtist)
        lyricsPresented = true
        lyricsPageOpacity = 0
        hidePlayerHero = true
        heroVisible = true
        applyPlayerFrames()

        scheduleFallback(after: 0.35) { [weak self] in self?.finishOpenLyrics() }
    }

    func closeLyrics() {
        guard lyricsPresented, !isAnimating else { return }
        isAnimating = true
        pending = .closeLyrics
        hidePlayerHero = true
        heroVisible = true
        applyLyricsFrames()

        let targetCover = frame(.playerCover, fallback: fallbackPlayerCover)
        let targetTitle = frame(.playerTitle, fallback: fallbackPlayerTitle)
        let targetArtist = frame(.playerArtist, fallback: fallbackPlayerArtist)

        withAnimation(.spring(response: 0.52, dampingFraction: 0.9)) {
            coverFrame = targetCover
            titleFrame = targetTitle
            artistFrame = targetArtist
            coverCornerRadius = 14
            titleFontSize = 20
            artistFontSize = 20
            titleColor = .white
            artistColor = .white.opacity(0.62)
            shadowOpacity = 0.55
            shadowRadius = 34
            shadowY = 22
            lyricsPageOpacity = 0
        }

        DispatchQueue.main.asyncAfter(deadline: .now() + 0.54) { [weak self] in
            guard let self else { return }
            self.lyricsPresented = false
            self.heroVisible = false
            self.hidePlayerHero = false
            self.isAnimating = false
            self.pending = nil
        }
    }

    private func finishOpenLyrics() {
        guard pending == .openLyrics else { return }
        pending = nil
        fallbackWorkItem?.cancel()

        let targetCover = frame(.lyricsCover, fallback: fallbackLyricsCover)
        let targetTitle = frame(.lyricsTitle, fallback: fallbackLyricsTitle)
        let targetArtist = frame(.lyricsArtist, fallback: fallbackLyricsArtist)

        withAnimation(.spring(response: 0.56, dampingFraction: 0.88)) {
            coverFrame = targetCover
            titleFrame = targetTitle
            artistFrame = targetArtist
            coverCornerRadius = 9
            titleFontSize = 17
            artistFontSize = 12
            titleColor = .white
            artistColor = .white.opacity(0.5)
            shadowOpacity = 0.28
            shadowRadius = 8
            shadowY = 4
        }
        withAnimation(.easeInOut(duration: 0.34)) {
            lyricsPageOpacity = 1
        }

        DispatchQueue.main.asyncAfter(deadline: .now() + 0.58) { [weak self] in
            guard let self else { return }
            self.heroVisible = false
            self.hidePlayerHero = false
            self.isAnimating = false
        }
    }

    // MARK: - Frames

    private func frame(_ anchor: HeroAnchor, fallback: CGRect) -> CGRect {
        guard let value = anchors[anchor], value.width > 1, value.height > 1 else {
            return fallback
        }
        return value
    }

    private func applyMiniFrames() {
        coverFrame = frame(.miniCover, fallback: fallbackMiniCover)
        titleFrame = frame(.miniTitle, fallback: fallbackMiniTitle)
        artistFrame = frame(.miniArtist, fallback: fallbackMiniArtist)
        coverCornerRadius = 10
        titleFontSize = 15
        artistFontSize = 11
        titleColor = AppTheme.primaryText
        artistColor = AppTheme.secondaryText
        shadowOpacity = 0.3
        shadowRadius = 8
        shadowY = 4
    }

    private func applyPlayerFrames() {
        coverFrame = frame(.playerCover, fallback: fallbackPlayerCover)
        titleFrame = frame(.playerTitle, fallback: fallbackPlayerTitle)
        artistFrame = frame(.playerArtist, fallback: fallbackPlayerArtist)
        coverCornerRadius = 14
        titleFontSize = 20
        artistFontSize = 20
        titleColor = .white
        artistColor = .white.opacity(0.62)
        shadowOpacity = 0.55
        shadowRadius = 34
        shadowY = 22
    }

    private func applyLyricsFrames() {
        coverFrame = frame(.lyricsCover, fallback: fallbackLyricsCover)
        titleFrame = frame(.lyricsTitle, fallback: fallbackLyricsTitle)
        artistFrame = frame(.lyricsArtist, fallback: fallbackLyricsArtist)
        coverCornerRadius = 9
        titleFontSize = 17
        artistFontSize = 12
        titleColor = .white
        artistColor = .white.opacity(0.5)
        shadowOpacity = 0.28
        shadowRadius = 8
        shadowY = 4
    }

    private func scheduleFallback(after seconds: TimeInterval, _ action: @escaping () -> Void) {
        fallbackWorkItem?.cancel()
        let item = DispatchWorkItem(block: action)
        fallbackWorkItem = item
        DispatchQueue.main.asyncAfter(deadline: .now() + seconds, execute: item)
    }

    // MARK: - Fallbacks (only used if a layout anchor is momentarily missing)

    private var fallbackMiniCapsule: CGRect {
        CGRect(x: 10, y: screenBounds.maxY - 128, width: screenBounds.width - 20, height: 64)
    }
    private var fallbackMiniCover: CGRect {
        CGRect(x: 21, y: screenBounds.maxY - 118, width: 46, height: 46)
    }
    private var fallbackMiniTitle: CGRect {
        CGRect(x: 78, y: screenBounds.maxY - 112, width: 190, height: 22)
    }
    private var fallbackMiniArtist: CGRect {
        CGRect(x: 78, y: screenBounds.maxY - 90, width: 150, height: 16)
    }
    private var fallbackPlayerCover: CGRect {
        let side = min(360, max(220, screenBounds.width - 48))
        return CGRect(x: (screenBounds.width - side) / 2, y: 100, width: side, height: side)
    }
    private var fallbackPlayerTitle: CGRect {
        CGRect(x: 24, y: fallbackPlayerCover.maxY + 24, width: screenBounds.width - 48, height: 28)
    }
    private var fallbackPlayerArtist: CGRect {
        CGRect(x: 24, y: fallbackPlayerTitle.maxY + 5, width: screenBounds.width - 48, height: 24)
    }
    private var fallbackLyricsCover: CGRect {
        CGRect(x: 62, y: 52, width: 46, height: 46)
    }
    private var fallbackLyricsTitle: CGRect {
        CGRect(x: 120, y: 54, width: screenBounds.width - 220, height: 22)
    }
    private var fallbackLyricsArtist: CGRect {
        CGRect(x: 120, y: 76, width: screenBounds.width - 220, height: 16)
    }
}

/// The one and only moving hero layer. It draws above every page so page
/// crossfades cannot fade the cover/title while they are moving.
struct HeroOverlayView: View {
    @ObservedObject var hero: HeroTransitionCoordinator

    var body: some View {
        GeometryReader { _ in
            ZStack(alignment: .topLeading) {
                if hero.backdropVisible {
                    RoundedRectangle(cornerRadius: hero.backdropCornerRadius, style: .continuous)
                        .fill(Color.black)
                        .frame(width: max(hero.backdropFrame.width, 1),
                               height: max(hero.backdropFrame.height, 1))
                        .position(x: hero.backdropFrame.midX, y: hero.backdropFrame.midY)
                        .opacity(hero.backdropOpacity)
                }

                if hero.heroVisible, let track = hero.heroTrack {
                    AsyncImage(url: track.picURL) { phase in
                        switch phase {
                        case .success(let image):
                            image.resizable().scaledToFill()
                        case .failure:
                            heroPlaceholder
                        default:
                            heroPlaceholder
                        }
                    }
                    .frame(width: max(hero.coverFrame.width, 1),
                           height: max(hero.coverFrame.height, 1))
                    .clipShape(RoundedRectangle(cornerRadius: hero.coverCornerRadius, style: .continuous))
                    .position(x: hero.coverFrame.midX, y: hero.coverFrame.midY)
                    .shadow(color: .black.opacity(hero.shadowOpacity),
                            radius: hero.shadowRadius,
                            y: hero.shadowY)

                    HeroText(
                        text: track.name,
                        frame: hero.titleFrame,
                        fontSize: hero.titleFontSize,
                        weight: .semibold,
                        color: hero.titleColor
                    )
                    HeroText(
                        text: track.singer,
                        frame: hero.artistFrame,
                        fontSize: hero.artistFontSize,
                        weight: .regular,
                        color: hero.artistColor
                    )
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
        .ignoresSafeArea()
        .allowsHitTesting(false)
    }

    private var heroPlaceholder: some View {
        LinearGradient(
            colors: [AppTheme.accent.opacity(0.8), Color.purple.opacity(0.55)],
            startPoint: .topLeading,
            endPoint: .bottomTrailing
        )
        .overlay(
            Image(systemName: "music.note")
                .font(.system(size: max(hero.coverFrame.width * 0.28, 16), weight: .semibold))
                .foregroundStyle(.white.opacity(0.9))
        )
    }
}

private struct HeroText: View {
    let text: String
    let frame: CGRect
    let fontSize: CGFloat
    let weight: Font.Weight
    let color: Color

    var body: some View {
        Text(text)
            .lineLimit(1)
            .modifier(HeroFontModifier(size: fontSize, weight: weight))
            .foregroundStyle(color)
            .frame(width: max(frame.width, 1), height: max(frame.height, 1), alignment: .leading)
            .position(x: frame.midX, y: frame.midY)
    }
}

private struct HeroFontModifier: AnimatableModifier {
    var size: CGFloat
    var weight: Font.Weight

    var animatableData: CGFloat {
        get { size }
        set { size = newValue }
    }

    func body(content: Content) -> some View {
        content.font(.system(size: size, weight: weight))
    }
}
