import SwiftUI

struct LibraryView: View {
    @EnvironmentObject private var library: LibraryStore
    @EnvironmentObject private var player: PlaybackCoordinator
    @EnvironmentObject private var downloads: DownloadManager
    @EnvironmentObject private var theme: ThemeStore
    @State private var showCreate = false
    @State private var newListName = ""

    var body: some View {
        NavigationStack {
            List {
                Section {
                    NavigationLink {
                        DownloadsView()
                    } label: {
                        HStack(spacing: 12) {
                            Image(systemName: "arrow.down.circle.fill")
                                .font(.system(size: 22, weight: .semibold))
                                .foregroundStyle(.white)
                                .frame(width: 46, height: 46)
                                .background(
                                    RoundedRectangle(cornerRadius: 9, style: .continuous)
                                        .fill(Color.blue.gradient)
                                )
                            VStack(alignment: .leading, spacing: 2) {
                                Text("已下载")
                                    .foregroundStyle(AppTheme.primaryText)
                                Text("\(downloads.items.count) 首")
                                    .font(.caption)
                                    .foregroundStyle(AppTheme.secondaryText)
                            }
                        }
                    }
                    .listRowBackground(AppTheme.card)
                } header: {
                    SectionHeader(title: "离线")
                }

                Section {
                    ForEach(library.playlists) { playlist in
                        NavigationLink {
                            PlaylistDetailView(playlistID: playlist.id)
                        } label: {
                            HStack(spacing: 12) {
                                if let artwork = playlist.artwork {
                                    ArtworkView(url: artwork, size: 46, cornerRadius: 9)
                                } else {
                                    Image(systemName: playlist.id == "love" ? "heart.fill" : playlist.id == "default" ? "clock.fill" : "music.note.list")
                                        .foregroundStyle(AppTheme.accent)
                                        .frame(width: 46, height: 46)
                                        .background(
                                            AppTheme.separator,
                                            in: RoundedRectangle(cornerRadius: 9, style: .continuous)
                                        )
                                }
                                VStack(alignment: .leading, spacing: 2) {
                                    Text(playlist.name).foregroundStyle(AppTheme.primaryText)
                                    Text("\(playlist.count) 首").font(.caption).foregroundStyle(AppTheme.secondaryText)
                                }
                            }
                        }
                        .listRowBackground(AppTheme.card)
                        .swipeActions {
                            if playlist.kind == .user {
                                Button(role: .destructive) {
                                    library.deleteUserList(id: playlist.id)
                                } label: {
                                    Label("删除歌单", systemImage: "trash")
                                }
                            }
                        }
                    }
                } header: {
                    SectionHeader(title: "我的歌单")
                }

                Section {
                    Button {
                        newListName = ""
                        showCreate = true
                    } label: {
                        Label("新建歌单", systemImage: "plus")
                            .foregroundStyle(AppTheme.accent)
                    }
                    .listRowBackground(AppTheme.card)
                }
            }
            .scrollContentBackground(.hidden)
            .background { AppBackgroundView() }
            .navigationTitle("音乐库")
            .alert("新建歌单", isPresented: $showCreate) {
                TextField("歌单名称", text: $newListName)
                Button("取消", role: .cancel) {}
                Button("创建") {
                    let name = newListName.trimmingCharacters(in: .whitespacesAndNewlines)
                    if !name.isEmpty { _ = library.createUserList(name: name) }
                }
            }
        }
    }
}

struct PlaylistDetailView: View {
    let playlistID: String
    @EnvironmentObject private var library: LibraryStore
    @EnvironmentObject private var player: PlaybackCoordinator
    @EnvironmentObject private var downloads: DownloadManager
    @EnvironmentObject private var settings: SettingsStore
    @Environment(\.dismiss) private var dismiss
    @State private var trackToAdd: MusicInfo?

    private var isUserList: Bool {
        library.playlists.first(where: { $0.id == playlistID })?.kind == .user
    }

    private var tracks: [MusicInfo] { library.tracks(for: playlistID) }
    private var title: String {
        library.playlists.first(where: { $0.id == playlistID })?.name ?? "歌单"
    }

    var body: some View {
        List {
            ForEach(tracks) { track in
                OnlineTrackRow(
                    track: track,
                    isCurrent: player.currentTrack?.id == track.id,
                    isPlaying: player.isPlaying,
                    onPlay: { player.play(track: track, queue: tracks) },
                    onAdd: { trackToAdd = track },
                    onPlayNext: { player.playNext(track) },
                    onDownload: { downloads.download(track, quality: settings.preferredQuality) }
                )
                .listRowBackground(AppTheme.card)
                .swipeActions {
                    Button(role: .destructive) {
                        library.remove(track.id, from: playlistID)
                    } label: { Label("删除", systemImage: "trash") }
                }
                .contextMenu {
                    Button {
                        trackToAdd = track
                    } label: {
                        Label("添加到其他歌单", systemImage: "text.badge.plus")
                    }
                    Button {
                        player.play(track: track, queue: tracks)
                    } label: {
                        Label("播放", systemImage: "play.fill")
                    }
                }
            }
        }
        .scrollContentBackground(.hidden)
        .background { AppBackgroundView() }
        .navigationTitle(title)
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                Menu {
                    Button {
                        guard let first = tracks.first else { return }
                        player.play(track: first, queue: tracks)
                    } label: {
                        Label("播放全部", systemImage: "play.fill")
                    }
                    .disabled(tracks.isEmpty)

                    if isUserList {
                        Divider()
                        Button(role: .destructive) {
                            library.deleteUserList(id: playlistID)
                            dismiss()
                        } label: {
                            Label("删除歌单", systemImage: "trash")
                        }
                    }
                } label: {
                    Image(systemName: "ellipsis.circle")
                }
            }
        }
        .overlay {
            if tracks.isEmpty {
                EmptyStateView(icon: "music.note.list", title: "歌单是空的", message: "从搜索页添加歌曲，或同步洛雪歌单。")
            }
        }
        .sheet(item: $trackToAdd) { track in
            PlaylistPickerSheet(track: track)
                .environmentObject(library)
        }
    }
}


struct DownloadsView: View {
    @EnvironmentObject private var downloads: DownloadManager
    @EnvironmentObject private var player: PlaybackCoordinator

    private var downloadedTracks: [MusicInfo] { downloads.items.map(\.track) }

    var body: some View {
        List {
            if downloads.items.isEmpty {
                VStack(spacing: 10) {
                    Image(systemName: "arrow.down.circle")
                        .font(.system(size: 38, weight: .ultraLight))
                        .foregroundStyle(AppTheme.secondaryText)
                    Text("还没有下载歌曲")
                        .font(.subheadline)
                        .foregroundStyle(AppTheme.secondaryText)
                    Text("在歌曲右侧的 + 菜单或播放页菜单中选择“下载”")
                        .font(.caption)
                        .foregroundStyle(AppTheme.secondaryText)
                        .multilineTextAlignment(.center)
                }
                .frame(maxWidth: .infinity)
                .padding(.vertical, 36)
                .listRowBackground(Color.clear)
                .listRowSeparator(.hidden)
            } else {
                Section {
                    ForEach(downloads.items) { item in
                        Button {
                            player.play(track: item.track, queue: downloadedTracks)
                        } label: {
                            HStack(spacing: 12) {
                                ArtworkView(url: item.track.picURL, size: 46, cornerRadius: 9)
                                VStack(alignment: .leading, spacing: 3) {
                                    Text(item.track.name)
                                        .foregroundStyle(AppTheme.primaryText)
                                        .lineLimit(1)
                                    Text(item.track.singer)
                                        .font(.caption)
                                        .foregroundStyle(AppTheme.secondaryText)
                                        .lineLimit(1)
                                    Text("\(item.quality.displayName) · \(byteText(item.fileSize))")
                                        .font(.caption2)
                                        .foregroundStyle(AppTheme.accent.opacity(0.9))
                                }
                                Spacer()
                                Image(systemName: player.currentTrack?.id == item.track.id && player.isPlaying ? "waveform" : "play.circle")
                                    .font(.title3)
                                    .foregroundStyle(player.currentTrack?.id == item.track.id ? AppTheme.accent : AppTheme.secondaryText)
                            }
                        }
                        .buttonStyle(.plain)
                        .listRowBackground(AppTheme.card)
                        .swipeActions {
                            Button(role: .destructive) {
                                downloads.remove(item.track)
                            } label: {
                                Label("删除下载", systemImage: "trash")
                            }
                        }
                    }
                } header: {
                    SectionHeader(title: "已下载")
                }
            }
        }
        .scrollContentBackground(.hidden)
        .background { AppBackgroundView() }
        .navigationTitle("已下载")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            if !downloads.items.isEmpty {
                Button {
                    if let first = downloads.items.first?.track {
                        player.play(track: first, queue: downloadedTracks)
                    }
                } label: {
                    Label("播放全部", systemImage: "play.fill")
                }
            }
        }
    }

    private func byteText(_ size: Int64) -> String {
        let formatter = ByteCountFormatter()
        formatter.countStyle = .file
        return formatter.string(fromByteCount: size)
    }
}
