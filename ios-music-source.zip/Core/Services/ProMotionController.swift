import UIKit
import QuartzCore

/// Keeps a lightweight CADisplayLink alive while the user asks for 120 Hz.
///
/// iOS only raises a ProMotion display to 120 Hz when the app explicitly asks
/// for it through `CADisplayLink.preferredFrameRateRange`. SwiftUI's own
/// animations follow the display once the window is running at 120 Hz, so a
/// single idle link is enough; it does no work in `tick`.
@MainActor
final class ProMotionController {
    static let shared = ProMotionController()

    private var displayLink: CADisplayLink?
    private(set) var isEnabled = false

    /// False on 60 Hz devices (including non-ProMotion iPhones).
    var isSupported: Bool {
        UIScreen.main.maximumFramesPerSecond > 60
    }

    var maximumFramesPerSecond: Int {
        UIScreen.main.maximumFramesPerSecond
    }

    func setEnabled(_ enabled: Bool) {
        guard enabled != isEnabled else { return }
        isEnabled = enabled
        if enabled {
            start()
        } else {
            stop()
        }
    }

    private func start() {
        stop()
        guard isSupported else { return }
        let link = CADisplayLink(target: self, selector: #selector(tick))
        link.preferredFrameRateRange = CAFrameRateRange(
            minimum: 120,
            maximum: 120,
            preferred: 120
        )
        link.add(to: .main, forMode: .common)
        displayLink = link
    }

    private func stop() {
        displayLink?.invalidate()
        displayLink = nil
    }

    @objc private func tick() {
        // The link's only job is to keep the display in its 120 Hz range.
    }
}
