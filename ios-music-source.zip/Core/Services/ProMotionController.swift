import UIKit
import QuartzCore

/// Keeps a lightweight CADisplayLink alive while the user asks for 120 Hz.
///
/// iOS only raises a ProMotion display to 120 Hz when the app explicitly asks
/// for it through `CADisplayLink.preferredFrameRateRange`. SwiftUI's own
/// animations follow the display once the window is running at 120 Hz, so a
/// single idle link is enough; it does no work in `tick`.
@MainActor
final class ProMotionController {
    static let shared = ProMotionController()

    private var displayLink: CADisplayLink?
    private var temporaryBoosts = 0
    private(set) var isEnabled = false

    /// True while either the user setting or a transition boost wants 120 Hz.
    var isActive: Bool { isEnabled || temporaryBoosts > 0 }

    /// False on 60 Hz devices (including non-ProMotion iPhones).
    var isSupported: Bool {
        UIScreen.main.maximumFramesPerSecond > 60
    }

    var maximumFramesPerSecond: Int {
        UIScreen.main.maximumFramesPerSecond
    }

    func setEnabled(_ enabled: Bool) {
        guard enabled != isEnabled else { return }
        isEnabled = enabled
        if isActive {
            start()
        } else {
            stop()
        }
    }

    /// Transitions ask for a short 120 Hz window even when the user has not
    /// enabled the persistent setting. This keeps the capsule animation at
    /// the display's native refresh rate without changing the saved setting.
    func beginTemporaryBoost() {
        temporaryBoosts += 1
        if isActive { start() }
    }

    func endTemporaryBoost() {
        temporaryBoosts = max(0, temporaryBoosts - 1)
        if !isActive { stop() }
    }

    private func start() {
        guard displayLink == nil else { return }
        guard isSupported else { return }
        let link = CADisplayLink(target: self, selector: #selector(tick))
        link.preferredFrameRateRange = CAFrameRateRange(
            minimum: 120,
            maximum: 120,
            preferred: 120
        )
        link.add(to: .main, forMode: .common)
        displayLink = link
    }

    private func stop() {
        displayLink?.invalidate()
        displayLink = nil
    }

    @objc private func tick() {
        // The link's only job is to keep the display in its 120 Hz range.
    }
}
