import Foundation
import UIKit

/// NetEase's EAPI request format, ported from kunyin's `NeteaseCrypto`.
///
/// The plain `/api/login/qrcode/*` endpoints no longer behave consistently;
/// the mobile client signs every request with AES-128-ECB over
/// `path-36cd479b6b5-json-36cd479b6b5-md5` and posts it to
/// `interface.music.163.com/eapi...`. The QR login in particular must use
/// `type=3` and read `MUSIC_U` from the poll response's `Set-Cookie`.
enum NetEaseEAPI {
    struct Result {
        let json: [String: Any]
        let cookie: String?
        let statusCode: Int
    }

    private static let key = Data("e82ckenh8dichen8".utf8)
    private static let appVersion = "3.1.17.204416"
    private static let versionCode = "140"
    private static let osVersion = "Microsoft-Windows-10-Professional-build-19045-64bit"
    private static let resolution = "1920x1080"
    private static let channel = "netease"
    private static let userAgent = "NeteaseMusic 9.0.90/5038 (iPhone; iOS 16.2; zh_CN)"

    /// Some carriers / networks reject the `interface.music.163.com`
    /// handshake (iOS reports NSURLErrorSecureConnectionFailed), while the
    /// same EAPI path is reachable on the other NetEase front doors. Try a
    /// small host list before surfacing a TLS error to the login screen.
    private static let hosts = [
        "music.163.com",
        "interface.music.163.com",
        "interface3.music.163.com"
    ]

    static func perform(
        path: String,
        data: [String: Any],
        musicU: String? = nil
    ) async throws -> Result {
        var lastError: Error?
        for host in hosts {
            let request: Request
            do {
                request = try build(path: path, data: data, musicU: musicU, host: host)
            } catch {
                lastError = error
                continue
            }

            // First the normal TLS stack, then a fresh TLS 1.2-only session.
            // A cached HTTP/3 route or a TLS 1.3 middlebox failure can both
            // make the first attempt fail while the second succeeds.
            for session in [standardSession, tls12Session] {
                do {
                    return try await send(request, session: session)
                } catch {
                    lastError = error
                    if !isRetryableNetworkError(error) { break }
                }
            }
        }
        throw lastError ?? NetEaseAccountError.response("无法连接网易云服务器")
    }

    private static func send(_ request: Request, session: URLSession) async throws -> Result {
        var urlRequest = URLRequest(url: request.url)
        urlRequest.httpMethod = "POST"
        urlRequest.timeoutInterval = 20
        for (key, value) in request.headers {
            urlRequest.setValue(value, forHTTPHeaderField: key)
        }
        urlRequest.httpBody = request.body

        let (data, response) = try await session.data(for: urlRequest)
        guard let http = response as? HTTPURLResponse else {
            throw NetEaseAccountError.response("不是 HTTP 响应")
        }
        guard (200..<300).contains(http.statusCode) else {
            throw NetEaseAccountError.response("HTTP \(http.statusCode)")
        }
        let object = try JSONSerialization.jsonObject(with: data, options: [.fragmentsAllowed])
        guard let json = object as? [String: Any] else {
            throw NetEaseAccountError.response("响应不是 JSON 对象")
        }
        return Result(
            json: json,
            cookie: cookieHeader(from: http, url: request.url),
            statusCode: http.statusCode
        )
    }

    private static func isRetryableNetworkError(_ error: Error) -> Bool {
        if error is URLError { return true }
        let ns = error as NSError
        return ns.domain == NSURLErrorDomain
    }

    private static let standardSession: URLSession = {
        let configuration = URLSessionConfiguration.ephemeral
        configuration.timeoutIntervalForRequest = 20
        configuration.timeoutIntervalForResource = 30
        configuration.requestCachePolicy = .reloadIgnoringLocalCacheData
        configuration.httpCookieStorage = .shared
        configuration.httpShouldSetCookies = true
        return URLSession(configuration: configuration)
    }()

    private static let tls12Session: URLSession = {
        let configuration = URLSessionConfiguration.ephemeral
        configuration.timeoutIntervalForRequest = 20
        configuration.timeoutIntervalForResource = 30
        configuration.requestCachePolicy = .reloadIgnoringLocalCacheData
        configuration.httpCookieStorage = .shared
        configuration.httpShouldSetCookies = true
        configuration.tlsMinimumSupportedProtocolVersion = .TLSv12
        configuration.tlsMaximumSupportedProtocolVersion = .TLSv12
        return URLSession(configuration: configuration)
    }()

    private struct Request {
        let url: URL
        let headers: [String: String]
        let body: Data
    }

    private static func build(
        path: String,
        data: [String: Any],
        musicU: String?,
        host: String
    ) throws -> Request {
        var header: [String: String] = [
            "osver": osVersion,
            "deviceId": deviceID(),
            "os": "pc",
            "appver": appVersion,
            "versioncode": versionCode,
            "mobilename": "",
            "buildver": String(Int(Date().timeIntervalSince1970)),
            "resolution": resolution,
            "__csrf": "",
            "channel": channel,
            "requestId": requestID()
        ]
        if let musicU, !musicU.isEmpty {
            header["MUSIC_U"] = musicU
        }

        var payload = data
        payload["header"] = header
        let jsonData = try JSONSerialization.data(withJSONObject: payload, options: [])
        guard let json = String(data: jsonData, encoding: .utf8) else {
            throw NetEaseAccountError.response("无法序列化登录参数")
        }

        let digest = MusicCrypto.md5Hex("nobody\(path)use\(json)md5forencrypt")
        let plain = "\(path)-36cd479b6b5-\(json)-36cd479b6b5-\(digest)"
        let encrypted = try MusicCrypto.aes128ECBPKCS7(Data(plain.utf8), key: key)
        let params = encrypted.map { String(format: "%02X", $0) }.joined()

        let suffix = path.hasPrefix("/api") ? String(path.dropFirst(4)) : path
        guard let url = URL(string: "https://\(host)/eapi\(suffix)") else {
            throw NetEaseAccountError.response("无效的 EAPI 地址")
        }
        let cookie = header.map { "\($0.key)=\($0.value)" }.joined(separator: "; ")
        return Request(
            url: url,
            headers: [
                "User-Agent": userAgent,
                "Accept": "application/json, text/plain, */*",
                "Content-Type": "application/x-www-form-urlencoded",
                "Cookie": cookie
            ],
            body: Data("params=\(params)".utf8)
        )
    }

    private static func cookieHeader(from response: HTTPURLResponse, url: URL) -> String? {
        var fields: [String: String] = [:]
        for (key, value) in response.allHeaderFields {
            fields[String(describing: key)] = String(describing: value)
        }
        var cookies = HTTPCookie.cookies(withResponseHeaderFields: fields, for: url)
        if cookies.isEmpty,
           let stored = HTTPCookieStorage.shared.cookies(for: URL(string: "https://music.163.com")!) {
            cookies = stored
        }
        let selected = cookies.filter { $0.name == "MUSIC_U" || $0.name == "__csrf" }
        if !selected.isEmpty {
            return selected.map { "\($0.name)=\($0.value)" }.joined(separator: "; ")
        }

        let raw = fields.first { $0.key.lowercased() == "set-cookie" }?.value ?? ""
        var pieces: [String] = []
        for name in ["MUSIC_U", "__csrf"] {
            if let range = raw.range(of: "\(name)=[^;\\s]+", options: .regularExpression) {
                pieces.append(String(raw[range]))
            }
        }
        return pieces.isEmpty ? nil : pieces.joined(separator: "; ")
    }

    private static func requestID() -> String {
        "\(Int(Date().timeIntervalSince1970))_\(String(format: "%04d", Int.random(in: 0...9999)))"
    }

    private static func deviceID() -> String {
        let key = "netease.eapi.deviceID"
        if let saved = UserDefaults.standard.string(forKey: key), !saved.isEmpty {
            return saved
        }
        let hex = "0123456789ABCDEF"
        let value = String((0..<52).map { _ in hex.randomElement() ?? "0" })
        UserDefaults.standard.set(value, forKey: key)
        return value
    }
}
