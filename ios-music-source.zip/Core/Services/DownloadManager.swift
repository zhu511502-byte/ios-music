import Foundation
import Combine

struct DownloadedTrack: Codable, Identifiable, Hashable {
    var id: String { track.id }
    let track: MusicInfo
    let quality: Quality
    let fileName: String
    let fileSize: Int64
    let downloadedAt: Date
}

/// Stores downloaded audio under Application Support and keeps its metadata
/// in a small JSON file. PlaybackResolver checks this store before asking the
/// LX source for a remote URL, so downloaded tracks keep playing offline.
@MainActor
final class DownloadManager: ObservableObject {
    static let shared = DownloadManager()

    @Published private(set) var items: [DownloadedTrack] = []
    @Published private(set) var activeIDs: Set<String> = []
    @Published var errorMessage: String?

    /// Set by AppModel. Kept as a closure so DownloadManager does not need to
    /// own a PlaybackResolver or a source runtime.
    var resolver: ((MusicInfo, Quality) async throws -> URL)?

    private let directory: URL
    private let metadataFile: URL
    private let encoder = JSONEncoder()
    private let decoder = JSONDecoder()

    init() {
        directory = AppPaths.root.appendingPathComponent("Downloads", isDirectory: true)
        metadataFile = AppPaths.root.appendingPathComponent("downloads.json")
        try? FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        if let data = try? Data(contentsOf: metadataFile),
           let saved = try? decoder.decode([DownloadedTrack].self, from: data) {
            items = saved.filter { FileManager.default.fileExists(atPath: directory.appendingPathComponent($0.fileName).path) }
        }
    }

    func isDownloaded(_ track: MusicInfo) -> Bool {
        items.contains { $0.track.id == track.id }
    }

    func isDownloading(_ track: MusicInfo) -> Bool {
        activeIDs.contains(track.id)
    }

    func downloadedURL(for track: MusicInfo, quality: Quality? = nil) -> URL? {
        let candidates: [DownloadedTrack]
        if let quality {
            let exact = items.filter { $0.track.id == track.id && $0.quality == quality }
            candidates = exact.isEmpty ? items.filter { $0.track.id == track.id } : exact
        } else {
            candidates = items.filter { $0.track.id == track.id }
        }
        guard let item = candidates.first else { return nil }
        let url = directory.appendingPathComponent(item.fileName)
        return FileManager.default.fileExists(atPath: url.path) ? url : nil
    }

    func download(_ track: MusicInfo, quality: Quality) {
        guard !activeIDs.contains(track.id), !isDownloaded(track) else { return }
        guard let resolver else {
            errorMessage = "下载器尚未初始化"
            return
        }

        activeIDs.insert(track.id)
        errorMessage = nil
        let trackID = track.id
        Task { [weak self] in
            guard let self else { return }
            defer { self.activeIDs.remove(trackID) }
            do {
                let remoteURL = try await resolver(track, quality)
                var request = URLRequest(url: remoteURL)
                request.timeoutInterval = 90
                request.setValue("Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X) LxPlayer", forHTTPHeaderField: "User-Agent")
                request.setValue("*/*", forHTTPHeaderField: "Accept")

                let (temporaryURL, response) = try await URLSession.shared.download(for: request)
                guard let http = response as? HTTPURLResponse,
                      (200..<300).contains(http.statusCode) else {
                    throw DownloadError.http((response as? HTTPURLResponse)?.statusCode ?? 0)
                }

                let ext = Self.fileExtension(response: response, remoteURL: remoteURL)
                let fileName = Self.fileName(track: track, quality: quality, extension: ext)
                let destination = self.directory.appendingPathComponent(fileName)
                try? FileManager.default.removeItem(at: destination)
                try FileManager.default.moveItem(at: temporaryURL, to: destination)

                let attributes = try? FileManager.default.attributesOfItem(atPath: destination.path)
                let size = (attributes?[.size] as? NSNumber)?.int64Value ?? 0
                self.items.removeAll { $0.track.id == track.id }
                self.items.insert(
                    DownloadedTrack(
                        track: track,
                        quality: quality,
                        fileName: fileName,
                        fileSize: size,
                        downloadedAt: Date()
                    ),
                    at: 0
                )
                self.save()
            } catch {
                self.errorMessage = "下载失败：\(error.localizedDescription)"
            }
        }
    }

    func remove(_ track: MusicInfo) {
        let removed = items.filter { $0.track.id == track.id }
        for item in removed {
            try? FileManager.default.removeItem(at: directory.appendingPathComponent(item.fileName))
        }
        items.removeAll { $0.track.id == track.id }
        save()
    }

    private func save() {
        guard let data = try? encoder.encode(items) else { return }
        try? data.write(to: metadataFile, options: .atomic)
    }

    private static func fileExtension(response: URLResponse, remoteURL: URL) -> String {
        let allowed = Set(["mp3", "flac", "m4a", "aac", "wav", "ape", "ogg", "opus"])
        let suggestedName = response.suggestedFilename ?? ""
        let suggested = (suggestedName as NSString).pathExtension.lowercased()
        if allowed.contains(suggested) { return suggested }
        let fromURL = remoteURL.pathExtension.lowercased()
        if allowed.contains(fromURL) { return fromURL }
        switch response.mimeType?.lowercased() {
        case "audio/flac", "audio/x-flac": return "flac"
        case "audio/mp4", "audio/x-m4a": return "m4a"
        case "audio/wav", "audio/x-wav": return "wav"
        case "audio/aac": return "aac"
        default: return "mp3"
        }
    }

    private static func fileName(track: MusicInfo, quality: Quality, extension ext: String) -> String {
        let raw = "\(track.source)-\(track.id)-\(quality.rawValue)"
        let safe = raw.replacingOccurrences(
            of: "[^A-Za-z0-9._-]",
            with: "_",
            options: .regularExpression
        )
        return "\(String(safe.prefix(80)))-\(UUID().uuidString.prefix(8)).\(ext)"
    }
}

enum DownloadError: LocalizedError {
    case http(Int)

    var errorDescription: String? {
        switch self {
        case .http(let code): return "服务器返回 HTTP \(code)"
        }
    }
}
